KHANIT INK — finished plates for GitHub

Repo:
https://github.com/wallstreetbranchmanager-tech/khanit-ink

Put files here (exact paths the site already uses):

  public/logo.jpg
  public/aftercare.jpg
  public/work/veil-rose-skull.jpg
  public/work/red-ink-butterflies.jpg
  public/work/sakura-leg.jpg
  public/work/studio-session.jpg
  public/work/black-snake.jpg
  public/work/oni-sleeve.jpg
  public/work/candle.jpg
  public/work/sun-spiral.jpg

GitHub web UI:
1. Open the repo
2. public/ → Add file → Upload files
3. Drag the public folder contents
4. Commit to main
5. Vercel rebuilds https://khanit-ink-072926.vercel.app

Do not upload through chat tools. Binary JPEGs fail that path.
Use GitHub web upload or git from your machine.

git from your computer:
  git clone https://github.com/wallstreetbranchmanager-tech/khanit-ink.git
  cp -R public/* khanit-ink/public/
  cd khanit-ink
  git add public
  git commit -m "Add branded gallery plates"
  git push
